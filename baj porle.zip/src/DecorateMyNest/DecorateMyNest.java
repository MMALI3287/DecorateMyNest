/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DecorateMyNest;

/**
 *
 * @author Musaddique Ali
 */
public class DecorateMyNest {
    public static void main(String[] args) {
        Welcome welcome=new Welcome();
        welcome.show();
    }
}
